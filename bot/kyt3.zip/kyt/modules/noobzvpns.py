from kyt import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile


# TRIAL NOOBZVPNS
@bot.on(events.CallbackQuery(data=b'trial-noobz'))
async def trial_noobz(event):
    user_id = str(event.sender_id)
    async def trial_noobz_(event):
        user = "trialX" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        ip = "1"
        
        

        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{ip}" | addnoobz'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Noobzvpn Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**» limit ip:** `{ip}`
**◇━━━━━━━━━━━━━━━━━◇**
**» PORT     :** `80`
**» PORT    :** `443`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Akun User:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@seaker877
"""
            inline = [
                [Button.url("𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖", "t.me/seaker877"),
                 Button.url("𝚆𝚑𝚊𝚝𝚜𝚊𝚙𝚙", "wa.me/6281335135082")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_noobz_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'trial-bob'))
async def trial_noobz(event):
    user_id = str(event.sender_id)
    async def trial_noobz_(event):
        user = "trialX" + str(random.randint(100, 1000))
        pw = "1"
        exp = "2"
        ip = "1"
        
        

        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{ip}" | addnoobz'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Noobzvpn Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**» limit ip:** `{ip}`
**◇━━━━━━━━━━━━━━━━━◇**
**» PORT     :** `80`
**» PORT    :** `443`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]`
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Akun User:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@seaker877
"""
            inline = [
                [Button.url("𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖", "t.me/seaker877"),
                 Button.url("𝚆𝚑𝚊𝚝𝚜𝚊𝚙𝚙", "wa.me/6281335135082")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_noobz_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'cek-noobz'))
async def cek_vmess(event):
    async def cek_noobz_(event):
        cmd = 'cek-noobz'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Noobz Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Users noobzvpns in databases**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "noobzvpns")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_noobz_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'noobzvpns'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("1 𝙷𝚊𝚛𝚒", "trial-noobz"),
            Button.inline("2 𝙷𝚊𝚛𝚒", "trial-bob")],
            [Button.inline("𝙻𝚒𝚜𝚝 𝚄𝚜𝚎𝚛", "cek-noobz")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸NOOBZVPNS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `NOOBZVPNS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@seaker877
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


