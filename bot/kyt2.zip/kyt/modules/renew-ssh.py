from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.renew-ssh|/renew-ssh)$"))
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def recov_ssh(event):
	async def recov_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be RENEW:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Days:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
			cmd = f'printf "%s\n" "{user}" "{pw}" | bot-renew-ssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"`{user}` ** TIDAK DITEMUKAN! **")
		else:
			await event.respond(f"""
```
{a}
```
**RENEW SSH**
**» 🤖@seaker877**
""",buttons=[[Button.inline(" Main Menu ","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await recov_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)