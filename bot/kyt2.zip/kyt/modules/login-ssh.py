from kyt import *
@bot.on(events.NewMessage(pattern=r"(?:.cek-ssh-login|/cek-ssh-login)$"))
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'cek-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Show Log SSH & OVPN User Login**
**» 🤖@seaker877**
""",buttons=[[Button.inline(" Main Menu ","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

