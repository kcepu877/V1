from kyt import *

@bot.on(events.CallbackQuery(data=b'create-akun'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    

    a = valid(str(sender.id))
    if a != "true":
        await event.answer("ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Quota:**")
        quota = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Limit-ip:**")
        limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired (in days):**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Perintah untuk membuat user SSH         
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Successful Create Account**")
            return

        # Hitung tanggal kadaluarsa
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Pesan hasil
        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
**◇⟨🔸Ssh & OpenVpn 🔸⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**» Port OpenSsh :** 443, 80, 22
**» Poer Dropbear :** 443, 109
**» Port Ssh Ws :** 80, 8080
**» Port Ssh Ws Ssl/Tls :** 443
**» Port Ssh UDP :** 1-65535 
**» Port Ovpn Ssl :** 443
**» Port Ovpn TCP :** 443, 1194
**» Port Ovpn UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨SSH UDP FOR HTTP CUSTOM⟩**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨OpenVpn⟩**
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired Until:** {later}
◇━━━━━━━━━━━━━━━━━◇
**» ** 🤖@seaker877
"""
        await event.respond(msg)
